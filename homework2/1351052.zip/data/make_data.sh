# Rotate image
sips -r 45 "$1.jpg" --out "$1.rotated.jpg"
# Resize image
sips -Z 400 "$1.jpg" --out "$1.resized.jpg"
# Flip image
sips -f horizontal "$1.jpg" --out "$1.flipped.jpg"